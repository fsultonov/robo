from django.contrib import admin
from . models import *
# Register your models here.

admin.site.register(Posts)
admin.site.register(AddStudent)
admin.site.register(ContactForm)
admin.site.register(StudentResults)
admin.site.register(BestStudents)
admin.site.register(ResultFile)
admin.site.register(Courses)
admin.site.register(FotoGallery)
admin.site.register(VideoGallery)
admin.site.register(Teachers)

@admin.register(FreeDays)
class FreeDaysAdmin(admin.ModelAdmin):
	list_display = ['year', 'month','day']
	list_editable = ['month','day']
