from django import forms
from . models import *

class StudentForm(forms.ModelForm):
	class Meta:
		model = AddStudent
		fields = ['name','course_name', 'phone']

