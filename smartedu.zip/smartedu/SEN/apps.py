from django.apps import AppConfig


class SenConfig(AppConfig):
    name = 'SEN'
