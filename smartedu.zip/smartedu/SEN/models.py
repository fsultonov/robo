from django.db import models
from django.urls import reverse
# Create your models here.

def image_folder(instance, filename):
	filename = instance.title +'.'+filename.split('.')[1]
	return"{0}/{1}".format(instance.title, filename) 

class Posts(models.Model):
	title = models.CharField('Nomi',max_length=250)
	image = models.ImageField('Foto', upload_to=image_folder)
	post = models.TextField('Matni', max_length=950)
	date = models.DateTimeField( auto_now_add = True)
	like = models.PositiveIntegerField(default=0)
	class Meta:
		verbose_name = 'Maqola'
		verbose_name_plural = 'Maqolalar'
	def __str__(self):
		return self.title

	def get_absolute_url(self):
		return reverse('SEN:posts',kwargs={'id':self.id})
 


class AddStudent(models.Model):
	name = models.CharField('Ismi',max_length=20)
	course_name = models.CharField('Kurs',max_length=25)
	phone = models.CharField('Telefon',max_length=15)
	class Meta:
		verbose_name = 'Student'
		verbose_name_plural = 'Studentlar'
	def __str__(self):
		return self.name

class ContactForm(models.Model):
	name = models.CharField('Ismingiz*', max_length=20)
	age = models.CharField('Yoshingiz', max_length=3)
	comment = models.TextField('Xabar matni', max_length=1500)
	class Meta:
		verbose_name = 'Aloqa'
		verbose_name_plural = 'Aloqalar'
	def __str__(self):
		return self.name

class FreeDays(models.Model):
	year = models.PositiveIntegerField(default=0)
	month = models.PositiveIntegerField(default=0)
	day = models.PositiveIntegerField(default=0)
	class Meta:
		verbose_name = 'Chegirma kun'
		verbose_name_plural = 'Chegirma kunlar'

	def __str__(self):
		return str(self.day)

class StudentResults(models.Model):
	name = models.CharField('Ism/Familyasi', max_length=25)
	group = models.CharField('Guruhi', max_length=35)
	result = models.PositiveIntegerField()
	date = models.DateTimeField(auto_now_add=True)
	comment = models.CharField('Izohi', max_length=10)
	class Meta:
		verbose_name = 'Talabalar reytengi'
		verbose_name_plural = 'Talabalar reytenglari'
	def __str__(self):
		return self.group

class BestStudents(models.Model):
	image = models.ImageField('Foto', upload_to=image_folder)
	name = models.CharField('Ismi', max_length=25)
	group = models.CharField('Guruhi', max_length=25)
	title = models.CharField('Izohi', max_length=35)
	class Meta:
		verbose_name = 'Faol talaba'
		verbose_name_plural = 'Faol talabalar'

	def __str__(self):
		return str(self.name)

def file_folder(instance, filename):
	filename = instance.name +'.'+filename.split('.')[1]
	return"{0}/{1}".format(instance.name, filename)

class Teachers(models.Model):
	image = models.ImageField('Foto', upload_to=image_folder)
	name = models.CharField('Ismi', max_length=25)
	category = models.CharField("Yo\'nalishi", max_length=45)
	title = models.CharField('Izohi', max_length=35)
	class Meta:
		verbose_name = 'Ustoz'
		verbose_name_plural = 'Ustozlar'

	def __str__(self):
		return str(self.name)

def file_folder(instance, filename):
	filename = instance.name +'.'+filename.split('.')[1]
	return"{0}/{1}".format(instance.name, filename)

class ResultFile(models.Model):
	file = models.FileField('Fayl',upload_to=file_folder)
	name = models.CharField('Nomi', max_length=50)
	class Meta:
		verbose_name = 'Natija fayl'
		verbose_name_plural = 'Natija fayllar'

	def __str__(self):
		return str(self.name)

class Courses(models.Model):
	image = models.ImageField('Kurs rasmi(870x517)', upload_to=image_folder)
	category = models.CharField('Turi', max_length=20 )
	name = models.CharField('Nomi', max_length=40)
	title = models.CharField('Izohi', max_length=70)
	students = models.PositiveIntegerField()
	lessons = models.PositiveIntegerField()
	class Meta:
		verbose_name = 'Kurs'
		verbose_name_plural = 'Kurslar'

	def __str__(self):
		return str(self.name)


class FotoGallery(models.Model):
	image = models.ImageField('Foto(870x870)', upload_to=image_folder)
	title = models.CharField('Izohi', max_length=10, blank=True)

class VideoGallery(models.Model):
	link = models.CharField('You Tube ssilka', max_length=90)