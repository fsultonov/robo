from django.shortcuts import render, get_object_or_404
from django.contrib import messages
from django.http import HttpResponseRedirect
from django.urls import reverse
from . models import *
from . forms import *

# Create your views here.
def index(request):
	if request.method == 'POST':
		form = StudentForm(request.POST or None)
		if form.is_valid():
			form.save()
			
		else:
			foto = FotoGallery.objects.all()
			courses = Courses.objects.all()
			teacher = Teachers.objects.all()
			student = BestStudents.objects.all().order_by('-id')
			freedays = FreeDays.objects.first()
			post = Posts.objects.all().order_by('-date')[:3]
			form = StudentForm()
			context = {'post': post, 'form':form, 'student':student,'teacher':teacher, 'freedays':freedays, 'courses':courses, 'foto':foto}
			return render(request, 'index.html',context)

	foto = FotoGallery.objects.all()
	courses = Courses.objects.all()
	teacher = Teachers.objects.all()
	student = BestStudents.objects.all().order_by('-id')
	freedays = FreeDays.objects.first()
	post = Posts.objects.all().order_by('-date')[:3]
	form = StudentForm()
	context = {'post': post, 'form':form, 'student':student,'teacher':teacher, 'freedays':freedays, 'courses':courses,'foto':foto}
	return render(request, 'index.html',context)


def contact(request):
	if request.method == 'POST':
		name = request.POST['name']
		age = request.POST['age']
		comment = request.POST['comment']

		try:
			ContactForm.objects.create(name=name, age=age, comment=comment)
			messages.add_message(request, messages.SUCCESS, 'Qabul qilindi aka!')
			return HttpResponseRedirect(reverse('SEN:contact'))
		except:
			messages.add_message(request, messages.WARNING, 'yemadi!')
			return HttpResponseRedirect(reverse('SEN:contact'))
				
	else:
		return render(request, 'contact.html')
		
def result(request):
	file = ResultFile.objects.order_by('-id')[:5]
	result = StudentResults.objects.order_by('-result')[:15]
	context = {'result':result, 'file':file}
	return render(request, 'result.html', context)	

def posts(request, id):
	post = get_object_or_404(Posts, id=id)
	context = {'post': post}
	return render(request, 'post.html', context)

def courses(request):
	return render(request, 'courses.html')